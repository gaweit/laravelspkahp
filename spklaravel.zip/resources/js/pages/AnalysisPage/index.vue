<template>
    <router-view></router-view>
</template>

<script>
import AnalysisCriteria from './AnalysisCriteriaPage'
export default {
    components: {
        AnalysisCriteria
    }
}
</script>
