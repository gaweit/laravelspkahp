<template>
    <a href="#" class="mr-3" @click.prevent="$router.go(-1)">
        <i class="fas fa-arrow-left"></i>
    </a>
</template>

<script>
export default {

}
</script>
