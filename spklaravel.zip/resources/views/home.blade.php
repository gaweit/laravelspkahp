@extends('layouts.app')

@section('content')
    <router-view class="mb-4"></router-view>
@endsection
