<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CriteriaPriority extends Model
{
    protected $fillable = ['criteria_id', 'value'];
}
