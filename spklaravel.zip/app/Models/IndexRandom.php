<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndexRandom extends Model
{
    protected $table = 'index_random';
    protected $fillable = ['n', 'IR'];
}
