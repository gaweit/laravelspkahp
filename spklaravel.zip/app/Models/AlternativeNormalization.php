<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AlternativeNormalization extends Model
{
    protected $fillable = ['comparison_id', 'value'];
}
