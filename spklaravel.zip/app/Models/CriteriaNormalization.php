<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CriteriaNormalization extends Model
{
    protected $fillable = ['comparison_id', 'value'];
}
